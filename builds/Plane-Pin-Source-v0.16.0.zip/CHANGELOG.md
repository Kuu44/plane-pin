# Changelog

All notable changes to Plane Pin are documented here.

This file follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project uses [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.16.0] - 2026-09-01

### Added

- Added a final “Start good habits!” onboarding page with a recommended launch-at-sign-in choice, quiet platform startup guidance, and a reminder that the preference can be changed later in Settings.

### Changed

- Login startup now keeps the requested preference separate from Windows, macOS, and Linux registration readback, so approval prompts, blocked entries, stale Linux autostart files, and development builds report their actual state.
- Settings now refreshes the launch-at-sign-in status after every save, including the exact macOS System Settings approval path and Windows startup recovery steps.
- macOS remains unsigned and unnotarised, so Login Items approval is not guaranteed; tray and startup behavior on real macOS and Linux hardware remains unverified until those packages are tested there.

### Fixed

- Windows startup registration now matches Plane Pin’s exact `--hidden` launch entry instead of treating another entry for the same executable as success.
- Linux startup checks now validate the XDG desktop entry, quoted executable path, hidden flag, and current executable before reporting it enabled.

## [0.15.0] - 2026-07-31

### Added

- Added Unassigned to the member picker, filtering, ordering, and member grouping so tasks without an assignee can appear in the rail.

### Fixed

- Restored configured T-shirt estimate labels in full and compact cards across current and older self-hosted Plane estimate payloads.

## [0.14.0] - 2026-07-27

### Added

- Added per-workflow-state checkmark actions in onboarding and Settings, with sensible next-state defaults and an explicit No change option for terminal or excluded states.
- Added a two-second state handoff that draws the checkmark, shows the previous and next states, and celebrates moves to In Review or completed states.
- Added a realistic, click-origin confetti overlay that spans the clicked monitor and keeps every particle visible until gravity carries it below the display.

### Changed

- Settings now opens as an independently movable native window and saves valid changes automatically.
- Appearance, filtering, grouping, and ordering changes update the cached task rail before the background Plane refresh runs.

### Fixed

- Removed the blurred Settings backdrop by moving Settings out of the task window.
- Configured T-shirt estimates now resolve when Plane returns a numeric estimate key instead of an estimate-point UUID.

## [0.13.1] - 2026-07-27

### Changed

- Refreshed Impeccable's design metadata to match the implemented light and dark water-blue palette, typography, component states, and current task interactions.
- Upgraded the release workflow to GitHub Actions that run on Node.js 24, and moved release builds to Node.js 24.

### Fixed

- Added a reproducible local renderer screenshot command that uses an installed Chrome or Edge browser when available and gives exact setup guidance when no compatible browser is present.
- Restored the live white insertion line while dragging members, projects, or workflow states, including correct clearing when the pointer returns to the dragged row.

## [0.13.0] - 2026-07-26

### Added

- Added persistent, accessible collapse controls for member and project task groups.
- Added stacked eight-second Undo actions after task state changes, including a real Plane state reversal and retry feedback.

### Changed

- Reordering members, projects, and workflow states now drags the full row, previews the exact insertion point, settles smoothly, and announces keyboard moves.
- Task completion controls now sit at the right edge with a larger target and one subtle hover halo.
- Settings layout changes apply immediately from the current task cache before Plane refreshes in the background.

### Fixed

- Tooltips now render above the application shell and stay inside the visible window.
- Stale or failed refreshes no longer overwrite current layout changes or hide already-loaded tasks.
- Compact completion animation no longer jumps vertically.

## [0.12.0] - 2026-07-26

### Added

- Added drag-to-reorder controls for members, projects, and workflow states; the task rail now follows those saved orders.
- Added optional member grouping, with project subgroups shown only when project grouping is also enabled.
- Added an optional task checkmark that changes the work item to a chosen Plane workflow state, then confirms success with animation, confetti, and an optional party sound.
- Added a glowing toolbar update button that appears only when an update is ready to download or install.

### Changed

- Switched automatic updates to the public GitHub release feed, removing the GitHub token field and its stored credential.
- Multi-assignee tasks appear once under the first matching member in the configured member order.

## [0.11.1] - 2026-07-26

### Changed

- Upgraded to Electron 42 and moved Linux Plane and GitHub tokens to its asynchronous operating-system credential storage, including automatic migration of existing encrypted tokens.

### Fixed

- Linux no longer treats a temporarily locked or unavailable system keyring as a deleted token or asks users to enter the token again.
- Plane Pin retries the saved token when tasks refresh after the Linux keyring becomes available.

## [0.11.0] - 2026-07-26

### Added

- Added a Start when I sign in preference on Windows, macOS, and Linux, with quiet launches that stay in the platform tray.
- Added an Updates section in Settings with automatic startup checks, download progress, and a one-click update, install, and restart action.
- Added encrypted storage for an optional read-only GitHub update token while the release repository remains private.

### Changed

- Packaged builds now explain why updates are unavailable instead of silently skipping checks; unsigned macOS builds direct users to the remaining signing requirement.

## [0.10.0] - 2026-07-26

### Changed

- Simplified onboarding and Settings to ask for the Plane workspace Home address, with beginner-friendly steps and a direct workspace-URL example.
- Updated connection validation to explain that the workspace name must be present in the pasted Home address.

## [0.9.0] - 2026-07-25

### Added

- Added a Priority appearance setting with Color dot and Card gradient choices; compact color dots are now the default.
- Added project estimate labels to full and compact task rows, including configured T-shirt sizes and legacy numeric estimates.

### Changed

- Compact rows now remove the external-link arrow entirely and keep the workflow-state icon at the right edge.

## [0.8.0] - 2026-07-25

### Added

- Added workspace-member discovery and member multiselects to onboarding and Settings, allowing one person, several people, everyone, or nobody to be shown.
- Added separate onboarding pages for members, projects, and workflow states, each with Select all and Select none actions.

### Changed

- Replaced project and workflow-state mode toggles with consistent multiselect lists that start fully selected.
- Darkened the water-wave texture in both themes; every gradient stop now gives white button text at least 6.0:1 contrast.

### Fixed

- Task filtering now applies selected assignees and exact state names locally after expanding Plane task data, avoiding unreliable self-hosted server-side assignee filtering.
- Preserved v0.8 filter data when quick settings are changed and retained legacy all-project/all-state behavior during settings migration.
- Normalized spacing between member, project, and workflow-state selectors.

## [0.7.1] - 2026-07-25

### Fixed

- Workspace discovery now skips Plane projects the connected account cannot access instead of failing the entire connection.
- Rebuilt every platform package from the same combined source so the Windows installer includes the inaccessible-project fix alongside the v0.7 water-blue UI.

## [0.7.0] - 2026-07-25

### Changed

- Replaced the violet accent with a layered water-blue wave treatment across active controls, primary actions, onboarding details, accent text, and app/tray icons in both themes.
- Enlarged every checkbox to a consistent 22px control with a full-row click target.
- Narrowed the refresh interval selector so its description has more breathing room in the minimum-width window.
- Moved the task link indicator to the bottom-right corner and tightened full and compact task rows to fit more work vertically.

### Fixed

- Settings now reopen at the last scroll position instead of jumping back to the first connection field.

## [0.6.0] - 2026-07-25

### Added

- Added a Plane Pin icon in the Windows notification area, the macOS menu bar, and the Linux system tray. Closing or minimising the window now parks the app there instead of ending it.
- Added a tray menu that shows or hides the window, refreshes tasks, toggles always on top and compact cards, opens Settings, and exits Plane Pin.
- Added press-and-hold dragging anywhere in task-only mode, so the rail moves the way it does from the title bar when the controls are visible.
- Added a Compact cards setting that shows only the task name and its state icon, fitting roughly twice as many tasks on screen.
- Added Window settings for closing and minimising to the tray, described using each platform's own name for that surface.
- Added universal macOS and x64 Linux packages. Every version tag builds them on their native operating systems and attaches them to its GitHub Release.
- Added a Plane Pin application icon and matching tray glyph, including a macOS template image that follows the menu bar's appearance.

### Changed

- Keyboard shortcuts and their tooltips use Command on macOS and Control elsewhere.
- The release workflow builds macOS and Linux packages on their own runners and publishes them together with the tracked Windows installer.
- A second launch reveals the running window instead of starting a rival instance and tray icon.

### Fixed

- Linux packages ship a desktop entry whose `StartupWMClass` matches the executable, plus icons at every standard size from 16px to 1024px, so desktops group Plane Pin windows and show a real icon.
- Desktops without a system tray keep ordinary window behaviour rather than hiding a window that could not be recovered.
- macOS uses its native traffic-light controls and hides them with the rest of the chrome in task-only mode.
- Secure-storage guidance now names the operating system credential store instead of referring only to Windows encryption.
- macOS tray menus avoid unsupported top-level disabled states.

## [0.5.0] - 2026-07-25

### Added

- Added a dedicated Settings dialog that remains available after the one-time onboarding flow.
- Added configurable automatic task refresh, defaulting to every five minutes.
- Added task rows that open their matching Plane issue in the default browser.
- Added light and dark themes in both the app toolbar and Settings.
- Added a frameless compact mode that hides the Windows title bar with the rest of the controls.

### Changed

- Updated the interface to use Inter, Plane-inspired state icons and chips, clearer gear and eye controls, and priority gradients across task cards.
- Replaced the always-on-top control with clearer active and inactive states.

### Fixed

- Settings now use one stable schema and canonical `%APPDATA%\plane-pin` location across versions.
- Token recovery now checks primary, backup, and legacy settings files without replacing newer non-secret preferences.
- Existing users with unreadable saved credentials are sent to Settings instead of being shown onboarding again.
- Removed horizontal scrolling at the minimum window width.
- Release tooling now preserves UTF-8 changelog text.

## [0.4.0] - 2026-07-25

### Added

- Added a guided first-run setup that explains how to find the Plane page address and create a personal access token.
- Added automatic discovery of the token owner, accessible projects, and each project’s exact workflow states.
- Added an All states option and multi-select filtering by exact state names across one or all projects.
- Added a task-only compact mode with a temporary Escape hint and floating window controls.
- Added keyboard shortcuts and hover tooltips for always-on-top, compact mode, refresh, and settings.

### Changed

- Replaced the ambiguous shared status-group selector with Plane’s actual project state names.
- Redesigned the always-on-top control so active and inactive states have distinct labels, icons, colors, and motion.
- Existing installations migrate to All states so no assigned tasks disappear unexpectedly.

### Fixed

- Preserved connection settings when Windows cannot decrypt a saved token instead of resetting the app to first-run defaults.
- Pinned settings to `%APPDATA%\plane-pin`, added atomic writes, and retained a valid settings backup across upgrades.
- Resolved custom states such as “In Review” separately from “In Progress” even when both belong to Plane’s Started group.

## [0.3.1] - 2026-07-25

### Added

- Added a complete release history and an `Unreleased` section for upcoming work.
- Added a pull request template that keeps release descriptions aligned with the changelog.
- Added a release merge command that copies the matching changelog entry into the version merge commit.

### Changed

- GitHub Releases now use the curated changelog entry instead of generated commit notes.

## [0.3.0] - 2026-07-25

### Added

- Added versioned Windows installers, source archives, updater metadata, and automated GitHub Releases.
- Added automatic update checks for packaged installations that have access to the private GitHub repository.
- Added repository rules for feature branches, stable version merges, and release verification.

### Changed

- Windows installers now preserve the stable application identity and user settings during upgrades.
- Release installers are stored with Git LFS under `builds/`.

## [0.2.0] - 2026-07-25

### Added

- Added profile-specific task filtering using the member ID from a Plane profile URL.
- Added assigned-task loading across all accessible projects or one selected project.
- Added shared status-group selection and optional project sections.
- Added inline setup guidance and a Show/Hide control for the personal access token.
- Added support for readable project keys such as `MKTG`.

## [0.1.0] - 2026-07-25

### Added

- Added the initial Windows Electron application with a compact, always-on-top task list.
- Added read-only loading and refreshing of started work items from a self-hosted Plane workspace.
- Added self-hosted Plane connection settings and encrypted token storage through Electron `safeStorage`.
- Added direct task links, keyboard-accessible controls, visible focus, and reduced-motion support.
- Added the first Windows NSIS installer and Plane API tests.

[Unreleased]: https://github.com/Kuu44/plane-pin/compare/v0.16.0...HEAD
[0.16.0]: https://github.com/Kuu44/plane-pin/compare/v0.15.0...v0.16.0
[0.13.1]: https://github.com/Kuu44/plane-pin/compare/v0.13.0...v0.13.1
[0.6.0]: https://github.com/Kuu44/plane-pin/compare/v0.5.0...v0.6.0
[0.5.0]: https://github.com/Kuu44/plane-pin/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.com/Kuu44/plane-pin/compare/v0.3.1...v0.4.0
[0.3.1]: https://github.com/Kuu44/plane-pin/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/Kuu44/plane-pin/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/Kuu44/plane-pin/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/Kuu44/plane-pin/releases/tag/v0.1.0

