# Plane Pin

A compact Electron companion that keeps your assigned self-hosted Plane work visible above other windows.

## Run

```powershell
npm.cmd install
npm.cmd start
```

The first launch opens a guided setup. You will need:

- Any page address from your logged-in Plane workspace
- A Plane personal access token created under Profile settings
- Your preferred projects and workflow states

Plane Pin normally identifies the token owner automatically. Older self-hosted versions can use the member UUID from a My Work profile URL as a fallback. Tasks are always restricted to that account. You can show every assigned task or select several exact state names from your projects.

The token is handled only by Electron's main process and persisted with Electron `safeStorage` when OS encryption is available.

Onboarding appears only when no completed setup exists. The separate Settings dialog remains available afterward and can change the connection, task filters, grouping, refresh interval, theme, and window behavior. Task rows open their Plane issue in the default browser, and the list refreshes every five minutes by default.

For a task URL such as `https://plane.example.com/engineering/browse/MKTG-17/`, setup detects:

- Plane URL: `https://plane.example.com`
- workspace: `engineering`

## Keyboard shortcuts

- `Ctrl+Shift+T`: toggle always on top
- `Ctrl+Shift+H`: toggle task-only compact mode
- `Ctrl+Shift+R`: refresh tasks
- `Ctrl+Shift+D`: toggle light/dark theme
- `Ctrl+,`: open settings
- `Escape`: leave compact mode

## Check and package

```powershell
npm.cmd test
npm.cmd run release:win
```

Commit source changes before running the release command. It tests and packages the app, then replaces `builds/` with the current version's installer, source archive, and updater metadata.

## Windows upgrades and settings

Running a newer Plane Pin installer upgrades the existing per-user installation because every version keeps the same Electron app ID. You do not need to uninstall first.

Settings survive both upgrades and normal uninstall/reinstall cycles. On this Windows installation they live at:

```text
%APPDATA%\plane-pin\settings.json
```

That is normally `C:\Users\<you>\AppData\Roaming\plane-pin\settings.json`. The Plane token is encrypted with Windows DPAPI through Electron `safeStorage`; it is not stored as readable text.

Settings use one versioned format, are written atomically, and keep the previous valid file as `settings.backup.json`. Upgrade recovery checks that backup plus legacy Plane Pin folder names, then migrates recovered data back to the canonical path. If Windows cannot unlock any saved token, Plane Pin preserves the rest of the setup, opens normally, and asks only for a replacement token in Settings.

The packaged app also checks for an update after launch. Because the GitHub repository is private, that check runs only when `GH_TOKEN` is set for the user launching Plane Pin. Do not put a GitHub token in the source or installer. A public release-only repository or another public HTTPS update feed would let normal installs update without a token.

When an update is found, `electron-updater` downloads the NSIS installer and installs it when the app exits. GitHub Releases are created automatically when a matching version tag such as `v0.3.0` is pushed.

See `AGENTS.md` for the branch, version, and release rules.

Release history is maintained in `CHANGELOG.md`. The same version entry is used in pull requests, release merge commits, and GitHub Releases.
